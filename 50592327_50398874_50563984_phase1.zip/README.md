# CSE587-Fall24-Project
Saagnik Sarbadhikari, 50592327
Marcus Hartman, 50398874
Bharath Reddy, 50563984

Team Number: 4


Datasets: 
https://www.huduser.gov/portal/datasets/fmr.html#null
https://www.zillow.com/research/data/
