hi grader,

this is the updated submission with my teammates' work. 
refer to piazza @85 for Marcus (50398874) earlier submission.

thanks!